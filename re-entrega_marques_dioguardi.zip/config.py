"""Target URLs to scrape."""

URLS = [
        [
                'https://www.rottentomatoes.com/m/wonder_woman_1984',
                'https://www.imdb.com/title/tt7126948/',
                'https://www.metacritic.com/movie/wonder-woman-1984',
                'https://www.ecartelera.com/peliculas/wonder-woman-1984',
        ],
]
